from turtle import Turtle

class Scoreboard(Turtle):
    """
    Manages the score display.

    Responsibilities:
    - Store score
    - Display score
    - Update score when increased
    - Reset score
    """

    def __init__(self):
        """Initialize scoreboard and display initial score."""
        super().__init__()
        self.score = 0
        self.penup()
        self.hideturtle()
        self.goto(0, 260)
        self.update_scoreboard()

    def increase_score(self):
        """Increase score and update display."""
        self.score += 1
        self.update_scoreboard()

    def update_scoreboard(self):
        """Clear and rewrite the current score."""
        self.clear()
        self.write(f"Score: {self.score}", align="center", font=("Arial", 20, "bold"))

    def reset(self):
        """Reset score to zero."""
        self.score = 0
        self.update_scoreboard()

    def game_over(self):
        """Display game over message."""
        self.clear()
        self.write(f"Score: {self.score}", font=("Arial", 60, "normal"))