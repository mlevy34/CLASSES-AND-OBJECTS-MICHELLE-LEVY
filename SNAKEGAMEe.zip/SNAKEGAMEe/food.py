from turtle import Turtle
import random

class Food:
    """
    Represents the food object.

    Responsibilities:
    - Appear on the screen
    - Move to a random position when eaten
    """

    def __init__(self):
        """Create the food object."""
        self.food = Turtle("circle")
        self.food.penup()

    def refresh(self):
        """Move food to a new random position."""
        self.food.goto(self.random_position())

    def random_position(self):
        """Generate a random valid position within the screen."""
        new_x = random.randint(-300, 300)
        new_y = random.randint(-250, 250)
        return new_x, new_y