from snake import Snake
from scoreboard import Scoreboard
from food import Food
from turtle import Screen
import time

class GameController:
    """
    Coordinates the game.

    Responsibilities:
    - Create game objects
    - Run the main game loop
    - Handle collisions
    - Update score
    - Reset the game when needed
    """

    def __init__(self):
        """Initialize the game and all components."""
        self.snake = Snake()
        self.food = Food()
        self.scoreboard = Scoreboard()
        self.is_game_on = True

        self.screen = Screen()
        self.screen.setup(width=700, height=600)
        self.screen.bgcolor("#09814a")
        self.screen.title("Snake Game")
        self.screen.tracer(0)

        self.setup_bindings()

    def setup_bindings(self):
        """Bind keyboard keys to snake movement."""
        self.screen.listen()
        self.screen.onkey(self.snake.up, "Up")
        self.screen.onkey(self.snake.down, "Down")
        self.screen.onkey(self.snake.left, "Left")
        self.screen.onkey(self.snake.right, "Right")

    def run_game_loop(self):
        """Run the main game loop."""
        while self.is_game_on:
            self.screen.update()
            time.sleep(0.2)
            self.snake.move()

            self.check_food_collision()
            self.check_wall_collision()
            self.check_self_collision()

    def check_food_collision(self):
        """Check if snake head touches food."""
        if self.snake.head.distance(self.food.food) <= 20:
            self.snake.grow()
            self.food.refresh()
            self.scoreboard.increase_score()

    def check_wall_collision(self):
        """Check if snake hits the wall."""
        bool1 = self.snake.head.xcor() < -340
        bool2 = self.snake.head.xcor() > 340
        bool3 = self.snake.head.ycor() < -280
        bool4 = self.snake.head.ycor() > 280

        if bool1 or bool2 or bool3 or bool4:
            self.reset_round()

    def check_self_collision(self):
        """Check if snake hits itself."""
        for segment in self.snake.segments[1:]:
            if self.snake.head.distance(segment) < 10:
                self.reset_round()

    def reset_round(self):
        """Reset game state after collision."""
        self.snake.reset()
        self.scoreboard.reset()
