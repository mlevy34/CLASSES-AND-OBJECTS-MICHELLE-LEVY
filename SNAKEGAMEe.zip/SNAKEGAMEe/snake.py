from turtle import Turtle

class Snake:
    """
    Represents the snake in the game.

    Responsibilities:
    - Create the snake body
    - Move the snake
    - Grow the snake
    - Reset the snake after collisions
    - Control direction safely (no reverse)
    """

    def __init__(self):
        """Initialize the snake with a starting body."""
        self.segments = []
        self.create_starting_snake()
        self.head = self.segments[0]

    def create_starting_snake(self):
        """Create the initial 3-segment snake."""
        for i in range(3):
            segment = Turtle("square")
            segment.penup()
            segment.goto(-i * 20, 0)
            self.segments.append(segment)

    def move(self):
        """Move the snake forward by having each segment follow the one ahead."""
        for i in range(len(self.segments)-1, 0, -1):
            self.segments[i].goto(self.segments[i-1].xcor(), self.segments[i-1].ycor())
        self.segments[0].forward(20)

    def grow(self):
        """Add a new segment to the end of the snake."""
        new_segment = Turtle("square")
        new_segment.penup()
        new_segment.goto(self.segments[-1].position())
        self.segments.append(new_segment)

    def reset(self):
        """Reset the snake to its starting state."""
        for i in range(len(self.segments)):
            self.segments[i].goto(1000, 1000)  # move old segments off screen
        self.segments.clear()
        self.create_starting_snake()
        self.head = self.segments[0]
        self.head.setheading(0)

    def up(self):
        """Change direction to up if not currently moving down."""
        if self.head.heading() != 270:
            self.head.setheading(90)

    def down(self):
        """Change direction to down if not currently moving up."""
        if self.head.heading() != 90:
            self.head.setheading(270)

    def right(self):
        """Change direction to right if not currently moving left."""
        if self.head.heading() != 180:
            self.head.setheading(0)

    def left(self):
        """Change direction to left if not currently moving right."""
        if self.head.heading() != 0:
            self.head.setheading(180)

