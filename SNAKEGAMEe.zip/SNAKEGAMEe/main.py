from GameController import GameController



game = GameController()
game.run_game_loop()
game.screen.exitonclick()
